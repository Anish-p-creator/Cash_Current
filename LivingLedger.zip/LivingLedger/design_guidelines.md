# Living Ledger Design Guidelines

## Design Approach
**Reference-Based Approach** - Drawing inspiration from modern fintech apps like Mint, YNAB, and banking apps, combined with data visualization principles from platforms like Linear and Notion. The design should feel approachable yet sophisticated, making financial data engaging rather than intimidating.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Dark Mode: Deep navy background (220 15% 12%) with bright accent blue (210 100% 65%)
- Light Mode: Clean white/light gray (0 0% 98%) with professional blue (210 85% 45%)
- Success/Positive: Green (142 70% 45%) for income and positive trends
- Warning/Neutral: Amber (35 85% 55%) for alerts and notifications
- Danger/Negative: Red (0 70% 50%) for expenses and negative trends

### Typography
- **Primary Font:** Inter via Google Fonts for excellent readability in financial data
- **Display Font:** Inter Bold for headers and key metrics
- **Monospace:** JetBrains Mono for numerical values and transaction amounts

### Layout System
**Tailwind Spacing:** Use consistent units of 2, 4, 6, and 8 for all spacing (p-2, m-4, gap-6, h-8)

### Component Library

**Navigation:**
- Clean sidebar with icon + text navigation
- Dashboard, Transactions, Insights, Settings sections
- Active state with subtle background highlight

**Data Visualization:**
- **Financial Heartbeat Graph:** Central animated line chart showing spending rhythm
- **Category Breakdown:** Donut charts with hover interactions
- **Timeline View:** Vertical transaction feed with category icons
- **Projection Cards:** Clean metric cards showing predicted balances

**Core Components:**
- Transaction cards with category icons and amount formatting
- Insight panels with trend arrows and percentage changes
- Balance display with large, prominent typography
- Filter controls with chip-style toggles

**Forms & Controls:**
- Minimal input styling with focus states
- Toggle switches for settings
- Date range pickers for transaction filtering

### Animations
**Minimal & Purposeful:**
- Gentle fade-ins for data loading states
- Smooth transitions for chart updates
- Subtle hover effects on interactive elements
- Loading skeleton screens for API data fetching

## Visual Treatment

**Background:** Clean, minimal backgrounds with subtle gradients (210 20% 98% to 210 15% 95%) in light mode

**Shadows:** Soft, elevated shadows for cards and modals using Tailwind's shadow-lg

**Borders:** Minimal border usage, prefer subtle background contrasts

**Data Presentation:**
- Large, bold typography for key financial metrics
- Color-coded spending categories with consistent iconography
- Progressive disclosure of detailed information
- Clear visual hierarchy prioritizing account balance and recent activity

## Key Design Principles
1. **Trust & Security:** Professional appearance with secure-feeling UI patterns
2. **Clarity:** Financial data must be immediately understandable
3. **Engagement:** Transform boring financial data into compelling visuals
4. **Accessibility:** High contrast ratios and readable typography throughout

## Images
**No Hero Image Required** - This is a dashboard-focused application where data visualization takes precedence over marketing imagery. Use iconography and charts as the primary visual elements.