import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, decimal, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Financial Transaction Schema
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  accountId: varchar("account_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  date: timestamp("date").notNull(),
  type: text("type").notNull(), // 'income' | 'expense'
});

// Account Schema
export const accounts = pgTable("accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  balance: decimal("balance", { precision: 10, scale: 2 }).notNull(),
  type: text("type").notNull(), // 'checking' | 'savings' | 'credit'
});

// User Schema
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Zod Schemas
export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
});

export const insertAccountSchema = createInsertSchema(accounts).omit({
  id: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Types
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Account = typeof accounts.$inferSelect;
export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Additional types for frontend
export type TransactionCategory = 
  | 'dining'
  | 'shopping'
  | 'transportation'
  | 'utilities'
  | 'entertainment'
  | 'healthcare'
  | 'income'
  | 'other';

export type SpendingInsight = {
  message: string;
  category: string;
  percentage: number;
  trend: 'up' | 'down' | 'stable';
};

export type BalanceProjection = {
  date: string;
  projectedBalance: number;
  confidence: number;
};
