import FinancialHeartbeat from '@/components/FinancialHeartbeat';
import BalanceCard from '@/components/BalanceCard';
import CategoryBreakdown from '@/components/CategoryBreakdown';
import TransactionTimeline from '@/components/TransactionTimeline';
import InsightCards from '@/components/InsightCards';
import BalanceProjection from '@/components/BalanceProjection';
import { Activity } from 'lucide-react';
import { Transaction, SpendingInsight, BalanceProjection as BalanceProjectionType } from '@shared/schema';

// TODO: Remove mock data when implementing real API integration
const mockHeartbeatData = [
  { date: '2024-09-15', balance: 2450.00, spending: 85.20 },
  { date: '2024-09-16', balance: 2380.15, spending: 120.45 },
  { date: '2024-09-17', balance: 2290.67, spending: 89.48 },
  { date: '2024-09-18', balance: 2205.19, spending: 185.25 },
  { date: '2024-09-19', balance: 2150.94, spending: 54.25 },
  { date: '2024-09-20', balance: 2300.19, spending: 45.30 },
  { date: '2024-09-21', balance: 2255.89, spending: 144.30 },
  { date: '2024-09-22', balance: 2180.59, spending: 75.30 },
  { date: '2024-09-23', balance: 2580.59, spending: 25.00 },
  { date: '2024-09-24', balance: 2455.29, spending: 125.30 },
];

const mockCategoryData = [
  { category: 'dining', amount: 320.45, percentage: 28.5, transactions: 15 },
  { category: 'shopping', amount: 245.20, percentage: 21.8, transactions: 8 },
  { category: 'transportation', amount: 180.30, percentage: 16.0, transactions: 12 },
  { category: 'utilities', amount: 150.00, percentage: 13.3, transactions: 4 },
  { category: 'entertainment', amount: 125.75, percentage: 11.2, transactions: 6 },
  { category: 'healthcare', amount: 85.40, percentage: 7.6, transactions: 3 },
  { category: 'other', amount: 18.90, percentage: 1.6, transactions: 2 },
];

const mockTransactions: Transaction[] = [
  {
    id: '1',
    accountId: 'acc1',
    amount: '85.45',
    description: 'Whole Foods Market',
    category: 'dining',
    date: new Date('2024-09-24T14:30:00'),
    type: 'expense'
  },
  {
    id: '2',
    accountId: 'acc1',
    amount: '2500.00',
    description: 'Payroll Deposit',
    category: 'income',
    date: new Date('2024-09-24T09:00:00'),
    type: 'income'
  },
  {
    id: '3',
    accountId: 'acc1',
    amount: '45.20',
    description: 'Uber Ride',
    category: 'transportation',
    date: new Date('2024-09-23T18:45:00'),
    type: 'expense'
  },
  {
    id: '4',
    accountId: 'acc1',
    amount: '150.00',
    description: 'Electric Bill',
    category: 'utilities',
    date: new Date('2024-09-23T10:15:00'),
    type: 'expense'
  },
  {
    id: '5',
    accountId: 'acc1',
    amount: '28.95',
    description: 'Netflix Subscription',
    category: 'entertainment',
    date: new Date('2024-09-22T12:00:00'),
    type: 'expense'
  },
];

const mockInsights: SpendingInsight[] = [
  {
    message: "You've spent 25% more on dining out this week compared to your average. Consider cooking at home to save money.",
    category: 'dining',
    percentage: 25.3,
    trend: 'up'
  },
  {
    message: "Great job! Your transportation costs are down 15% this month thanks to using public transit more often.",
    category: 'transportation',
    percentage: -15.2,
    trend: 'down'
  },
  {
    message: "Shopping expenses have increased by 30% this week. Most purchases were at Target and Amazon.",
    category: 'shopping',
    percentage: 30.7,
    trend: 'up'
  },
  {
    message: "Your entertainment spending is within your normal range. You're maintaining good balance between fun and savings.",
    category: 'entertainment',
    percentage: 2.1,
    trend: 'stable'
  }
];

const mockProjections: BalanceProjectionType[] = [
  { date: '2024-09-25', projectedBalance: 2380.29, confidence: 95 },
  { date: '2024-09-27', projectedBalance: 2205.15, confidence: 92 },
  { date: '2024-09-30', projectedBalance: 1950.85, confidence: 88 },
  { date: '2024-10-03', projectedBalance: 1725.40, confidence: 85 },
  { date: '2024-10-07', projectedBalance: 1580.20, confidence: 82 },
  { date: '2024-10-10', projectedBalance: 1420.95, confidence: 78 },
  { date: '2024-10-14', projectedBalance: 1285.50, confidence: 75 },
  { date: '2024-10-17', projectedBalance: 1155.25, confidence: 72 },
  { date: '2024-10-21', projectedBalance: 1045.80, confidence: 68 },
  { date: '2024-10-24', projectedBalance: 952.35, confidence: 65 },
];

const totalSpent = mockCategoryData.reduce((sum, item) => sum + item.amount, 0);

export default function Dashboard() {
  return (
    <div className="space-y-8 p-6 max-w-7xl mx-auto" data-testid="page-dashboard">
      {/* Account Balance Cards */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <BalanceCard
          balance={2455.29}
          change={125.30}
          changePercentage={5.4}
          accountName="Primary Checking"
          accountType="checking"
        />
        <BalanceCard
          balance={8950.15}
          change={-45.20}
          changePercentage={-0.5}
          accountName="Emergency Fund"
          accountType="savings"
        />
        <BalanceCard
          balance={1250.75}
          change={85.40}
          changePercentage={7.3}
          accountName="Rewards Card"
          accountType="credit"
        />
      </section>

      {/* Financial Heartbeat - Main Feature */}
      <section className="relative">
        <div className="absolute -inset-1 bg-gradient-to-r from-chart-1/20 to-chart-2/20 rounded-lg blur-sm"></div>
        <div className="relative">
          <FinancialHeartbeat data={mockHeartbeatData} />
        </div>
      </section>

      {/* Insights */}
      <section className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-chart-1/10">
            <Activity className="w-5 h-5 text-chart-1" />
          </div>
          <div>
            <h2 className="text-2xl font-bold tracking-tight">Smart Insights</h2>
            <p className="text-muted-foreground">AI-powered analysis of your spending patterns</p>
          </div>
        </div>
        <InsightCards insights={mockInsights} />
      </section>

      {/* Analytics Row */}
      <section className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <CategoryBreakdown data={mockCategoryData} totalSpent={totalSpent} />
        <TransactionTimeline transactions={mockTransactions} />
      </section>

      {/* Balance Projection */}
      <section className="relative">
        <div className="absolute -inset-1 bg-gradient-to-r from-chart-3/10 to-chart-1/10 rounded-lg blur-sm"></div>
        <div className="relative">
          <BalanceProjection projections={mockProjections} currentBalance={2455.29} />
        </div>
      </section>
    </div>
  );
}