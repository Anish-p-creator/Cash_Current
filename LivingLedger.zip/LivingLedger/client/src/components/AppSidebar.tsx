import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarGroupLabel, 
  SidebarMenu, 
  SidebarMenuButton, 
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter 
} from '@/components/ui/sidebar';
import { 
  LayoutDashboard, 
  Activity, 
  TrendingUp, 
  CreditCard, 
  PieChart, 
  Settings, 
  HelpCircle,
  Heart
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useLocation } from 'wouter';

const navigationItems = [
  {
    title: 'Dashboard',
    url: '/',
    icon: LayoutDashboard,
  },
  {
    title: 'Transactions',
    url: '/transactions',
    icon: CreditCard,
  },
  {
    title: 'Analytics',
    url: '/analytics',
    icon: PieChart,
  },
  {
    title: 'Projections',
    url: '/projections',
    icon: TrendingUp,
  },
];

const secondaryItems = [
  {
    title: 'Settings',
    url: '/settings',
    icon: Settings,
  },
  {
    title: 'Help',
    url: '/help',
    icon: HelpCircle,
  },
];

export function AppSidebar() {
  const [location] = useLocation();

  const isActive = (url: string) => {
    if (url === '/') {
      return location === '/';
    }
    return location.startsWith(url);
  };

  return (
    <Sidebar data-testid="sidebar-main">
      <SidebarHeader className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-chart-1/20 to-chart-1/5 border border-chart-1/20">
            <Heart className="w-6 h-6 text-chart-1" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight" data-testid="text-app-title">
              Living Ledger
            </h1>
            <p className="text-sm text-muted-foreground">
              Your Financial Heartbeat
            </p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Overview</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigationItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={isActive(item.url)}
                    data-testid={`nav-${item.title.toLowerCase()}`}
                  >
                    <a href={item.url} onClick={(e) => {
                      e.preventDefault();
                      console.log(`Navigating to ${item.url}`);
                      // Note: In real app, this would use wouter's navigation
                    }}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Account Status</SidebarGroupLabel>
          <SidebarGroupContent>
            <div className="px-3 py-4 space-y-3 bg-sidebar/30 rounded-lg mx-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Total Balance</span>
                <span className="text-lg font-mono font-bold text-foreground" data-testid="text-sidebar-balance">
                  $12,656.19
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">This Month</span>
                <Badge variant="destructive" className="text-xs font-semibold" data-testid="badge-sidebar-monthly">
                  -$1,245.30
                </Badge>
              </div>
            </div>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Quick Insights</SidebarGroupLabel>
          <SidebarGroupContent>
            <div className="px-3 py-2 space-y-3">
              <div className="p-3 rounded-lg bg-chart-4/10 border border-chart-4/30 hover-elevate">
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-1 rounded bg-chart-4/20">
                    <Activity className="w-3 h-3 text-chart-4" />
                  </div>
                  <span className="text-sm font-semibold text-chart-4">Alert</span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Dining spending up 25% this week
                </p>
              </div>
              
              <div className="p-3 rounded-lg bg-chart-2/10 border border-chart-2/30 hover-elevate">
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-1 rounded bg-chart-2/20">
                    <TrendingUp className="w-3 h-3 text-chart-2" />
                  </div>
                  <span className="text-sm font-semibold text-chart-2">Good Job!</span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Transportation costs down 15%
                </p>
              </div>
            </div>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <SidebarMenu>
          {secondaryItems.map((item) => (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton 
                asChild 
                size="sm"
                isActive={isActive(item.url)}
                data-testid={`nav-${item.title.toLowerCase()}`}
              >
                <a href={item.url} onClick={(e) => {
                  e.preventDefault();
                  console.log(`Navigating to ${item.url}`);
                }}>
                  <item.icon className="w-4 h-4" />
                  <span>{item.title}</span>
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}