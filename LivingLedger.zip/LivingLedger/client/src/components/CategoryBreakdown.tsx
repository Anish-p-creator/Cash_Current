import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PieChart, ShoppingBag, Car, Utensils, Gamepad2, Stethoscope, Home, DollarSign } from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend);

interface CategoryData {
  category: string;
  amount: number;
  percentage: number;
  transactions: number;
}

interface CategoryBreakdownProps {
  data: CategoryData[];
  totalSpent: number;
}

const categoryIcons: Record<string, any> = {
  dining: Utensils,
  shopping: ShoppingBag,
  transportation: Car,
  utilities: Home,
  entertainment: Gamepad2,
  healthcare: Stethoscope,
  other: DollarSign,
};

export default function CategoryBreakdown({ data, totalSpent }: CategoryBreakdownProps) {
  const chartData = {
    labels: data.map(item => item.category.charAt(0).toUpperCase() + item.category.slice(1)),
    datasets: [
      {
        data: data.map(item => item.amount),
        backgroundColor: [
          'hsl(var(--chart-1) / 0.8)',
          'hsl(var(--chart-2) / 0.8)',
          'hsl(var(--chart-3) / 0.8)',
          'hsl(var(--chart-4) / 0.8)',
          'hsl(var(--chart-5) / 0.8)',
          'hsl(var(--primary) / 0.6)',
          'hsl(var(--secondary) / 0.8)',
        ],
        borderColor: [
          'hsl(var(--chart-1))',
          'hsl(var(--chart-2))',
          'hsl(var(--chart-3))',
          'hsl(var(--chart-4))',
          'hsl(var(--chart-5))',
          'hsl(var(--primary))',
          'hsl(var(--secondary))',
        ],
        borderWidth: 2,
        hoverBorderWidth: 3,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'hsl(var(--popover))',
        titleColor: 'hsl(var(--popover-foreground))',
        bodyColor: 'hsl(var(--popover-foreground))',
        borderColor: 'hsl(var(--popover-border))',
        borderWidth: 1,
        cornerRadius: 8,
        padding: 12,
        callbacks: {
          label: function(context: any) {
            const percentage = ((context.parsed / totalSpent) * 100).toFixed(1);
            return `$${context.parsed.toFixed(2)} (${percentage}%)`;
          },
        },
      },
    },
    cutout: '65%',
  };

  return (
    <Card className="w-full" data-testid="card-category-breakdown">
      <CardHeader className="pb-6">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-3 text-xl font-semibold">
            <div className="p-2 rounded-lg bg-chart-3/10">
              <PieChart className="w-5 h-5 text-chart-3" />
            </div>
            <div>
              <div className="text-xl font-semibold">Spending by Category</div>
              <div className="text-sm text-muted-foreground font-normal">Your spending breakdown this month</div>
            </div>
          </CardTitle>
          <div className="text-right">
            <div className="text-2xl font-bold font-mono">
              ${totalSpent.toFixed(2)}
            </div>
            <div className="text-sm text-muted-foreground">Total spent</div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="h-64 w-full" data-testid="chart-category-breakdown">
            <Doughnut data={chartData} options={options} />
          </div>
          <div className="space-y-3">
            {data.map((item, index) => {
              const Icon = categoryIcons[item.category] || DollarSign;
              return (
                <div 
                  key={item.category} 
                  className="flex items-center justify-between p-4 rounded-lg hover-elevate border border-border/40 transition-all duration-200 hover:border-border/60"
                  data-testid={`item-category-${item.category}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-muted/50">
                      <Icon className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium capitalize" data-testid={`text-category-name-${item.category}`}>
                        {item.category}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {item.transactions} transactions
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold font-mono" data-testid={`text-category-amount-${item.category}`}>
                      ${item.amount.toFixed(2)}
                    </p>
                    <Badge 
                      variant="secondary" 
                      className="text-xs"
                      data-testid={`badge-category-percentage-${item.category}`}
                    >
                      {item.percentage.toFixed(1)}%
                    </Badge>
                  </div>
                </div>
              );
            })}\n          </div>
        </div>
      </CardContent>
    </Card>
  );
}