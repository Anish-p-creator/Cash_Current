import { Line } from 'react-chartjs-2';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Calendar, Target } from 'lucide-react';
import { BalanceProjection as BalanceProjectionType } from '@shared/schema';

interface BalanceProjectionProps {
  projections: BalanceProjectionType[];
  currentBalance: number;
}

export default function BalanceProjection({ projections, currentBalance }: BalanceProjectionProps) {
  const chartData = {
    labels: projections.map(p => new Date(p.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
    datasets: [
      {
        label: 'Projected Balance',
        data: projections.map(p => p.projectedBalance),
        borderColor: 'hsl(var(--chart-1))',
        backgroundColor: 'hsl(var(--chart-1) / 0.1)',
        borderWidth: 3,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: 'hsl(var(--chart-1))',
        pointBorderColor: 'hsl(var(--background))',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7,
        borderDash: [5, 5],
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'hsl(var(--popover))',
        titleColor: 'hsl(var(--popover-foreground))',
        bodyColor: 'hsl(var(--popover-foreground))',
        borderColor: 'hsl(var(--popover-border))',
        borderWidth: 1,
        cornerRadius: 8,
        padding: 12,
        callbacks: {
          label: function(context: any) {
            const confidence = projections[context.dataIndex]?.confidence || 0;
            return `Projected: $${context.parsed.y.toFixed(2)} (${confidence}% confidence)`;
          },
        },
      },
    },
    scales: {
      x: {
        grid: {
          color: 'hsl(var(--border) / 0.3)',
          drawOnChartArea: true,
        },
        ticks: {
          color: 'hsl(var(--muted-foreground))',
          font: {
            family: 'var(--font-sans)',
            size: 11,
          },
        },
      },
      y: {
        grid: {
          color: 'hsl(var(--border) / 0.3)',
          drawOnChartArea: true,
        },
        ticks: {
          color: 'hsl(var(--muted-foreground))',
          font: {
            family: 'var(--font-mono)',
            size: 11,
          },
          callback: function(value: any) {
            return `$${value}`;
          },
        },
      },
    },
  };

  const finalProjection = projections[projections.length - 1];
  const projectedChange = finalProjection ? finalProjection.projectedBalance - currentBalance : 0;
  const isPositiveChange = projectedChange >= 0;
  
  // Calculate average confidence
  const avgConfidence = projections.reduce((sum, p) => sum + p.confidence, 0) / projections.length;

  return (
    <Card className="w-full" data-testid="card-balance-projection">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-xl font-semibold">
          <TrendingUp className="w-5 h-5 text-chart-1" />
          30-Day Balance Projection
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Projected Balance (30 days)</p>
              <p className="text-2xl font-bold font-mono" data-testid="text-projected-balance">
                ${finalProjection?.projectedBalance.toFixed(2) || '0.00'}
              </p>
            </div>
            <div className="text-right space-y-2">
              <div className="flex items-center gap-2">
                <Badge 
                  variant={isPositiveChange ? "default" : "destructive"}
                  className="font-mono"
                  data-testid="badge-projected-change"
                >
                  {isPositiveChange ? '+' : ''}${projectedChange.toFixed(2)}
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Target className="w-4 h-4" />
                <span data-testid="text-confidence">
                  {avgConfidence.toFixed(0)}% confidence
                </span>
              </div>
            </div>
          </div>
          
          <div className="h-64 w-full" data-testid="chart-balance-projection">
            <Line data={chartData} options={options} />
          </div>
          
          <div className="bg-muted/30 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Calendar className="w-5 h-5 text-chart-1 mt-0.5" />
              <div>
                <p className="font-medium text-sm">Projection Details</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Based on your spending patterns from the last 90 days. The projection assumes 
                  similar spending habits and income schedule. Actual results may vary.
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}