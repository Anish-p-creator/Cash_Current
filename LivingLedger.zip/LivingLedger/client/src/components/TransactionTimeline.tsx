import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Clock, ArrowUpRight, ArrowDownLeft, ShoppingBag, Car, Utensils, Gamepad2, Stethoscope, Home, DollarSign } from 'lucide-react';
import { Transaction } from '@shared/schema';

interface TransactionTimelineProps {
  transactions: Transaction[];
}

const categoryIcons: Record<string, any> = {
  dining: Utensils,
  shopping: ShoppingBag,
  transportation: Car,
  utilities: Home,
  entertainment: Gamepad2,
  healthcare: Stethoscope,
  income: DollarSign,
  other: DollarSign,
};

const getCategoryColor = (category: string) => {
  const colors: Record<string, string> = {
    dining: 'bg-chart-1/10 text-chart-1',
    shopping: 'bg-chart-2/10 text-chart-2',
    transportation: 'bg-chart-3/10 text-chart-3',
    utilities: 'bg-chart-4/10 text-chart-4',
    entertainment: 'bg-chart-5/10 text-chart-5',
    healthcare: 'bg-destructive/10 text-destructive',
    income: 'bg-chart-2/10 text-chart-2',
    other: 'bg-muted/10 text-muted-foreground',
  };
  return colors[category] || colors.other;
};

export default function TransactionTimeline({ transactions }: TransactionTimelineProps) {
  const sortedTransactions = [...transactions].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        year: date.getFullYear() !== today.getFullYear() ? 'numeric' : undefined 
      });
    }
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <Card className="w-full" data-testid="card-transaction-timeline">
      <CardHeader className="pb-6">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-3 text-xl font-semibold">
            <div className="p-2 rounded-lg bg-chart-1/10">
              <Clock className="w-5 h-5 text-chart-1" />
            </div>
            <div>
              <div className="text-xl font-semibold">Recent Transactions</div>
              <div className="text-sm text-muted-foreground font-normal">Your latest activity</div>
            </div>
          </CardTitle>
          <Badge variant="outline" className="text-xs">
            {sortedTransactions.length} transactions
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-80 w-full pr-4" data-testid="scroll-transactions">
          <div className="space-y-3">
            {sortedTransactions.map((transaction, index) => {
              const Icon = categoryIcons[transaction.category] || DollarSign;
              const isIncome = transaction.type === 'income';
              const amount = parseFloat(transaction.amount);
              
              return (
                <div 
                  key={transaction.id}
                  className="flex items-center gap-4 p-4 rounded-lg border border-border/40 hover-elevate transition-all duration-200 hover:border-border/60 hover:shadow-sm"
                  data-testid={`item-transaction-${index}`}
                >
                  <div className={`p-2.5 rounded-lg ${getCategoryColor(transaction.category)} shadow-sm`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium truncate" data-testid={`text-transaction-description-${index}`}>
                        {transaction.description}
                      </p>
                      <Badge 
                        variant="secondary" 
                        className={`text-xs ${getCategoryColor(transaction.category)}`}
                        data-testid={`badge-transaction-category-${index}`}
                      >
                        {transaction.category}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span data-testid={`text-transaction-date-${index}`}>
                        {formatDate(transaction.date.toString())}
                      </span>
                      <span>•</span>
                      <span data-testid={`text-transaction-time-${index}`}>
                        {formatTime(transaction.date.toString())}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-right">
                    <div className={`flex items-center gap-1 ${isIncome ? 'text-chart-2' : 'text-foreground'}`}>
                      {isIncome ? (
                        <ArrowUpRight className="w-4 h-4" />
                      ) : (
                        <ArrowDownLeft className="w-4 h-4" />
                      )}
                      <span className="font-semibold font-mono" data-testid={`text-transaction-amount-${index}`}>
                        {isIncome ? '+' : '-'}${Math.abs(amount).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}