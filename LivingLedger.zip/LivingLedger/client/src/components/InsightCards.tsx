import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, AlertTriangle, Target, Brain } from 'lucide-react';
import { SpendingInsight } from '@shared/schema';

interface InsightCardsProps {
  insights: SpendingInsight[];
}

export default function InsightCards({ insights }: InsightCardsProps) {
  const getInsightIcon = (trend: string) => {
    switch (trend) {
      case 'up': return TrendingUp;
      case 'down': return TrendingDown;
      default: return Target;
    }
  };

  const getInsightColor = (trend: string) => {
    switch (trend) {
      case 'up': return 'text-chart-4 bg-chart-4/10';
      case 'down': return 'text-chart-2 bg-chart-2/10';
      default: return 'text-chart-3 bg-chart-3/10';
    }
  };

  const getBadgeVariant = (percentage: number) => {
    if (Math.abs(percentage) > 20) return 'destructive';
    if (Math.abs(percentage) > 10) return 'secondary';
    return 'outline';
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-testid="grid-insights">
      {insights.map((insight, index) => {
        const Icon = getInsightIcon(insight.trend);
        const isAlert = Math.abs(insight.percentage) > 20;
        
        return (
          <Card 
            key={index} 
            className={`hover-elevate border-border/40 transition-all duration-200 ${isAlert ? 'border-chart-4/50 bg-chart-4/5' : ''}`}
            data-testid={`card-insight-${index}`}
          >
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-3">
                <div className="p-1.5 rounded-md bg-chart-1/10">
                  <Brain className="w-4 h-4 text-chart-1" />
                </div>
                <span className="text-foreground">Smart Insight</span>
              </CardTitle>
              {isAlert && (
                <div className="p-1.5 rounded-md bg-chart-4/10">
                  <AlertTriangle className="w-4 h-4 text-chart-4" data-testid={`icon-alert-${index}`} />
                </div>
              )}
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-4">
                <p className="text-sm leading-relaxed text-foreground" data-testid={`text-insight-message-${index}`}>
                  {insight.message}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge 
                      variant="outline" 
                      className="text-xs capitalize font-medium"
                      data-testid={`badge-insight-category-${index}`}
                    >
                      {insight.category}
                    </Badge>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-md ${getInsightColor(insight.trend)}`}>
                      <Icon className="w-3 h-3" />
                      <span className="text-xs font-medium capitalize">{insight.trend}</span>
                    </div>
                  </div>
                  
                  <Badge 
                    variant={getBadgeVariant(insight.percentage)}
                    className="font-mono text-sm font-bold px-3 py-1"
                    data-testid={`badge-insight-percentage-${index}`}
                  >
                    {insight.percentage > 0 ? '+' : ''}{insight.percentage.toFixed(1)}%
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}