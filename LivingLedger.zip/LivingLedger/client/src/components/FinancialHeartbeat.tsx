import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity } from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface FinancialHeartbeatProps {
  data: {
    date: string;
    balance: number;
    spending: number;
  }[];
}

export default function FinancialHeartbeat({ data }: FinancialHeartbeatProps) {
  const chartData = {
    labels: data.map(d => new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
    datasets: [
      {
        label: 'Account Balance',
        data: data.map(d => d.balance),
        borderColor: 'hsl(var(--chart-1))',
        backgroundColor: 'hsl(var(--chart-1) / 0.1)',
        borderWidth: 3,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: 'hsl(var(--chart-1))',
        pointBorderColor: 'hsl(var(--background))',
        pointBorderWidth: 2,
        pointRadius: 6,
        pointHoverRadius: 8,
      },
      {
        label: 'Daily Spending',
        data: data.map(d => -d.spending),
        borderColor: 'hsl(var(--chart-4))',
        backgroundColor: 'hsl(var(--chart-4) / 0.1)',
        borderWidth: 2,
        fill: false,
        tension: 0.4,
        pointBackgroundColor: 'hsl(var(--chart-4))',
        pointBorderColor: 'hsl(var(--background))',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          usePointStyle: true,
          padding: 20,
          color: 'hsl(var(--foreground))',
          font: {
            family: 'var(--font-sans)',
            size: 12,
            weight: 'bold',
          },
        },
      },
      tooltip: {
        backgroundColor: 'hsl(var(--popover))',
        titleColor: 'hsl(var(--popover-foreground))',
        bodyColor: 'hsl(var(--popover-foreground))',
        borderColor: 'hsl(var(--popover-border))',
        borderWidth: 1,
        cornerRadius: 8,
        padding: 12,
        displayColors: true,
        callbacks: {
          label: function(context: any) {
            const label = context.dataset.label || '';
            const value = context.parsed.y;
            if (label === 'Daily Spending') {
              return `${label}: $${Math.abs(value).toFixed(2)}`;
            }
            return `${label}: $${value.toFixed(2)}`;
          },
        },
      },
    },
    scales: {
      x: {
        grid: {
          color: 'hsl(var(--border) / 0.5)',
          drawOnChartArea: true,
        },
        ticks: {
          color: 'hsl(var(--muted-foreground))',
          font: {
            family: 'var(--font-sans)',
            size: 11,
          },
        },
      },
      y: {
        grid: {
          color: 'hsl(var(--border) / 0.5)',
          drawOnChartArea: true,
        },
        ticks: {
          color: 'hsl(var(--muted-foreground))',
          font: {
            family: 'var(--font-mono)',
            size: 11,
          },
          callback: function(value: any) {
            return `$${value}`;
          },
        },
      },
    },
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
    elements: {
      point: {
        hoverBorderWidth: 3,
      },
    },
  };

  return (
    <Card className="w-full" data-testid="card-financial-heartbeat">
      <CardHeader className="pb-6">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-3 text-xl font-semibold">
            <div className="p-2 rounded-lg bg-chart-1/10">
              <Activity className="w-5 h-5 text-chart-1" data-testid="icon-heartbeat" />
            </div>
            <div>
              <div className="text-xl font-semibold">Financial Heartbeat</div>
              <div className="text-sm text-muted-foreground font-normal">Your spending rhythm over time</div>
            </div>
          </CardTitle>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-chart-1"></div>
              <span>Balance</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-chart-4"></div>
              <span>Spending</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-80 w-full" data-testid="chart-heartbeat">
          <Line data={chartData} options={options} />
        </div>
      </CardContent>
    </Card>
  );
}