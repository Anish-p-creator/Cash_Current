import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';

interface BalanceCardProps {
  balance: number;
  change: number;
  changePercentage: number;
  accountName: string;
  accountType: 'checking' | 'savings' | 'credit';
}

export default function BalanceCard({ 
  balance, 
  change, 
  changePercentage, 
  accountName, 
  accountType 
}: BalanceCardProps) {
  const isPositive = change >= 0;
  const TrendIcon = isPositive ? TrendingUp : TrendingDown;
  
  const getAccountTypeColor = (type: string) => {
    switch (type) {
      case 'checking': return 'bg-chart-1/10 text-chart-1';
      case 'savings': return 'bg-chart-2/10 text-chart-2';
      case 'credit': return 'bg-chart-4/10 text-chart-4';
      default: return 'bg-muted/10 text-muted-foreground';
    }
  };

  return (
    <Card className="hover-elevate border-border/40 transition-all duration-200" data-testid={`card-balance-${accountType}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-muted/30">
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </div>
          <div>
            <CardTitle className="text-sm font-medium text-foreground">
              {accountName}
            </CardTitle>
            <Badge 
              variant="outline" 
              className={`text-xs mt-1 ${getAccountTypeColor(accountType)} border-current/20`}
              data-testid={`badge-account-type-${accountType}`}
            >
              {accountType}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="text-3xl font-bold font-mono tracking-tight" data-testid={`text-balance-${accountType}`}>
            ${balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="flex items-center justify-between">
            <div className={`flex items-center space-x-2 px-2 py-1 rounded-md ${isPositive ? 'bg-chart-2/10 text-chart-2' : 'bg-chart-4/10 text-chart-4'}`}>
              <TrendIcon className="w-3 h-3" />
              <span className="text-sm font-medium" data-testid={`text-change-${accountType}`}>
                {isPositive ? '+' : ''}${change.toFixed(2)}
              </span>
              <span className="text-xs opacity-80">
                ({isPositive ? '+' : ''}{changePercentage.toFixed(1)}%)
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              vs. last week
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}