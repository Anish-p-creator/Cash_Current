import FinancialHeartbeat from '../FinancialHeartbeat';

// Mock data showing the "heartbeat" of financial activity
const mockData = [
  { date: '2024-09-15', balance: 2450.00, spending: 85.20 },
  { date: '2024-09-16', balance: 2380.15, spending: 120.45 },
  { date: '2024-09-17', balance: 2290.67, spending: 89.48 },
  { date: '2024-09-18', balance: 2205.19, spending: 185.25 },
  { date: '2024-09-19', balance: 2150.94, spending: 54.25 },
  { date: '2024-09-20', balance: 2300.19, spending: 45.30 },
  { date: '2024-09-21', balance: 2255.89, spending: 144.30 },
  { date: '2024-09-22', balance: 2180.59, spending: 75.30 },
  { date: '2024-09-23', balance: 2580.59, spending: 25.00 },
  { date: '2024-09-24', balance: 2455.29, spending: 125.30 },
];

export default function FinancialHeartbeatExample() {
  return <FinancialHeartbeat data={mockData} />;
}