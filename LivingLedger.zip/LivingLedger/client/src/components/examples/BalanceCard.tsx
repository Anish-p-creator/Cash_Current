import BalanceCard from '../BalanceCard';

export default function BalanceCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <BalanceCard
        balance={2455.29}
        change={125.30}
        changePercentage={5.4}
        accountName="Primary Checking"
        accountType="checking"
      />
      <BalanceCard
        balance={8950.15}
        change={-45.20}
        changePercentage={-0.5}
        accountName="Emergency Fund"
        accountType="savings"
      />
      <BalanceCard
        balance={1250.75}
        change={85.40}
        changePercentage={7.3}
        accountName="Rewards Card"
        accountType="credit"
      />
    </div>
  );
}