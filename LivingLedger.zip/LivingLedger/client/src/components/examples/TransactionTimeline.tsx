import TransactionTimeline from '../TransactionTimeline';
import { Transaction } from '@shared/schema';

const mockTransactions: Transaction[] = [
  {
    id: '1',
    accountId: 'acc1',
    amount: '85.45',
    description: 'Whole Foods Market',
    category: 'dining',
    date: new Date('2024-09-24T14:30:00'),
    type: 'expense'
  },
  {
    id: '2',
    accountId: 'acc1',
    amount: '2500.00',
    description: 'Payroll Deposit',
    category: 'income',
    date: new Date('2024-09-24T09:00:00'),
    type: 'income'
  },
  {
    id: '3',
    accountId: 'acc1',
    amount: '45.20',
    description: 'Uber Ride',
    category: 'transportation',
    date: new Date('2024-09-23T18:45:00'),
    type: 'expense'
  },
  {
    id: '4',
    accountId: 'acc1',
    amount: '150.00',
    description: 'Electric Bill',
    category: 'utilities',
    date: new Date('2024-09-23T10:15:00'),
    type: 'expense'
  },
  {
    id: '5',
    accountId: 'acc1',
    amount: '28.95',
    description: 'Netflix Subscription',
    category: 'entertainment',
    date: new Date('2024-09-22T12:00:00'),
    type: 'expense'
  },
  {
    id: '6',
    accountId: 'acc1',
    amount: '125.30',
    description: 'Target Shopping',
    category: 'shopping',
    date: new Date('2024-09-22T16:20:00'),
    type: 'expense'
  },
  {
    id: '7',
    accountId: 'acc1',
    amount: '75.60',
    description: 'Doctor Visit Copay',
    category: 'healthcare',
    date: new Date('2024-09-21T11:30:00'),
    type: 'expense'
  },
];

export default function TransactionTimelineExample() {
  return <TransactionTimeline transactions={mockTransactions} />;
}