import InsightCards from '../InsightCards';
import { SpendingInsight } from '@shared/schema';

const mockInsights: SpendingInsight[] = [
  {
    message: "You've spent 25% more on dining out this week compared to your average. Consider cooking at home to save money.",
    category: 'dining',
    percentage: 25.3,
    trend: 'up'
  },
  {
    message: "Great job! Your transportation costs are down 15% this month thanks to using public transit more often.",
    category: 'transportation',
    percentage: -15.2,
    trend: 'down'
  },
  {
    message: "Your entertainment spending is within your normal range. You're maintaining good balance between fun and savings.",
    category: 'entertainment',
    percentage: 2.1,
    trend: 'stable'
  },
  {
    message: "Shopping expenses have increased by 30% this week. Most purchases were at Target and Amazon.",
    category: 'shopping',
    percentage: 30.7,
    trend: 'up'
  }
];

export default function InsightCardsExample() {
  return <InsightCards insights={mockInsights} />;
}