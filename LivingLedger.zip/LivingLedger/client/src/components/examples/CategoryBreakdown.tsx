import CategoryBreakdown from '../CategoryBreakdown';

const mockCategoryData = [
  { category: 'dining', amount: 320.45, percentage: 28.5, transactions: 15 },
  { category: 'shopping', amount: 245.20, percentage: 21.8, transactions: 8 },
  { category: 'transportation', amount: 180.30, percentage: 16.0, transactions: 12 },
  { category: 'utilities', amount: 150.00, percentage: 13.3, transactions: 4 },
  { category: 'entertainment', amount: 125.75, percentage: 11.2, transactions: 6 },
  { category: 'healthcare', amount: 85.40, percentage: 7.6, transactions: 3 },
  { category: 'other', amount: 18.90, percentage: 1.6, transactions: 2 },
];

const totalSpent = mockCategoryData.reduce((sum, item) => sum + item.amount, 0);

export default function CategoryBreakdownExample() {
  return <CategoryBreakdown data={mockCategoryData} totalSpent={totalSpent} />;
}