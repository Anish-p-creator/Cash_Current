import BalanceProjection from '../BalanceProjection';
import { BalanceProjection as BalanceProjectionType } from '@shared/schema';

const mockProjections: BalanceProjectionType[] = [
  { date: '2024-09-25', projectedBalance: 2380.29, confidence: 95 },
  { date: '2024-09-27', projectedBalance: 2205.15, confidence: 92 },
  { date: '2024-09-30', projectedBalance: 1950.85, confidence: 88 },
  { date: '2024-10-03', projectedBalance: 1725.40, confidence: 85 },
  { date: '2024-10-07', projectedBalance: 1580.20, confidence: 82 },
  { date: '2024-10-10', projectedBalance: 1420.95, confidence: 78 },
  { date: '2024-10-14', projectedBalance: 1285.50, confidence: 75 },
  { date: '2024-10-17', projectedBalance: 1155.25, confidence: 72 },
  { date: '2024-10-21', projectedBalance: 1045.80, confidence: 68 },
  { date: '2024-10-24', projectedBalance: 952.35, confidence: 65 },
];

export default function BalanceProjectionExample() {
  return <BalanceProjection projections={mockProjections} currentBalance={2455.29} />;
}